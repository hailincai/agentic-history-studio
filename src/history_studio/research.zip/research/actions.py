from enum import StrEnum

from pydantic import Field

from history_studio.models.base import Contract, Identifier, Text
from history_studio.models.research import ResearchFact
from history_studio.models.research_package import ResearchPlan


class SearchRequest(Contract):
    query: Text = Field(max_length=500)


class ReadRequest(Contract):
    source_id: Identifier


class Recommendation(StrEnum):
    CONTINUE = "CONTINUE"
    COMPLETE = "COMPLETE"


class ResearchUpdate(Contract):
    plan: ResearchPlan
    facts: list[ResearchFact] = Field(default_factory=list, max_length=20)
    recommendation: Recommendation


def action_contracts() -> dict[str, type[Contract]]:
    return {"search_web": SearchRequest, "read_source": ReadRequest, "checkpoint_research": ResearchUpdate}
