import json
from collections.abc import Callable
from pathlib import Path
from uuid import uuid4

from pydantic import BaseModel, ValidationError

from history_studio.models.project import ProjectConfig
from history_studio.models.research_package import (
    GapStatus, ResearchPackage, ResearchProgress, ResearchRunStatus,
)
from history_studio.storage.artifact_store import ArtifactStore, write_json
from history_studio.workflow import ProjectState, ProjectStateMachine, RuntimeState
from .actions import Recommendation, ReadRequest, ResearchUpdate, SearchRequest, action_contracts
from .boundaries import ResearchProvider, ResearchTools, ToolCall, ToolObservation
from .config import ResearchSettings
from .context import ContextLimitError, build_context
from .usage import LimitReached, UsageLedger
from .web_tools import canonical_url, normalize_text, source_reference


class ResearchAgent:
    """One local writer; every attempt is bounded and every iteration is checkpointed.

    Providers choose actions. Python owns permission checks, source-derived excerpts,
    guardrails, persistence and the workflow's completion transition.
    """

    def __init__(self, provider: ResearchProvider, tools: ResearchTools, settings: ResearchSettings,
                 emit: Callable[[str], None] | None = None) -> None:
        self.provider = provider
        self.tools = tools
        self.settings = settings
        self.emit = emit or (lambda event: None)

    def run(self, project: ProjectConfig, store: ArtifactStore,
            runtime_configuration: BaseModel | None = None) -> ResearchPackage:
        runtime = store.project_dir / ".runtime"
        runtime.mkdir(parents=True, exist_ok=True)
        lock = runtime / "research.lock"
        try:
            with lock.open("x", encoding="utf-8") as stream:
                stream.write("Research run active; remove only after confirming no runner is active.")
        except FileExistsError as exc:
            raise ValueError("Research lock exists; another run may be active. Inspect before removing it.") from exc
        try:
            if runtime_configuration is not None:
                write_json(runtime / "research_config.json", runtime_configuration, replace=True)
            return self._run(project, store, runtime)
        finally:
            lock.unlink(missing_ok=True)

    def _load_package(self, project: ProjectConfig, store: ArtifactStore) -> ResearchPackage | None:
        versions = store.list_versions("research")
        for version in reversed(versions):
            try:
                package = store.load("research", version, ResearchPackage)
            except (ValidationError, OSError):
                self.emit(f"Skipping invalid research checkpoint v{version}")
                continue
            if (package.project_id != project.project_id or package.topic != project.topic
                    or package.research_scope != project.research_scope):
                raise ValueError("Research checkpoint belongs to a different project/topic/scope")
            return package
        if versions:
            raise ValueError("No valid research checkpoint; refusing to discard prior work")
        return None

    def _run(self, project: ProjectConfig, store: ArtifactStore, runtime: Path) -> ResearchPackage:
        if store.project_dir.name != project.project_id:
            raise ValueError("Project ID must match the artifact directory")
        state_path = runtime / "state.json"
        machine = ProjectStateMachine(RuntimeState.model_validate_json(state_path.read_text(encoding="utf-8")))
        if machine.resume_state not in (ProjectState.CREATED, ProjectState.RESEARCHING, ProjectState.RESEARCH_COMPLETE):
            raise ValueError("Research cannot run from the current workflow stage")
        package = self._load_package(project, store)
        usage_path = runtime / "research_usage.json"
        if package and package.progress.status == ResearchRunStatus.COMPLETE:
            self._check_completion(package)
            self._finish_workflow(machine, state_path)
            self.emit("Research already complete; no provider calls made")
            return package
        if machine.state.current_state == ProjectState.RESEARCH_COMPLETE:
            raise ValueError("Workflow is complete but no valid completed research package exists")
        if package and not usage_path.exists():
            raise ValueError("Resume requires the runtime usage ledger; refusing to reset consumed budget")
        ledger = (UsageLedger.model_validate_json(usage_path.read_text(encoding="utf-8"))
                  if usage_path.exists() else UsageLedger(run_id=uuid4().hex))
        if package and ledger.run_id != package.progress.run_id:
            raise ValueError("Checkpoint and usage ledger run IDs do not match")
        if ledger.pending_request:
            ledger.unknown_usage = True
            ledger.pending_request = False
        ledger.persist(usage_path)
        if package is None:
            package = ResearchPackage(project_id=project.project_id, topic=project.topic,
                                      research_scope=project.research_scope,
                                      progress=ResearchProgress(run_id=ledger.run_id))
            self._checkpoint(package, store)
        if machine.state.current_state == ProjectState.FAILED:
            machine.recover()
        if machine.state.current_state == ProjectState.CREATED:
            machine.transition(ProjectState.RESEARCHING)
        write_json(state_path, machine.state, replace=True)
        write_json(runtime / "research_settings.json", self.settings, replace=True)
        hard_budget = min(self.settings.hard_budget_usd, project.budget_usd)
        observation: tuple[ToolCall, str] | None = None
        while True:
            operation = "guardrails"
            try:
                if ledger.iterations_started >= self.settings.max_iterations:
                    raise LimitReached("iteration_limit")
                ledger.iterations_started += 1
                ledger.persist(usage_path)
                package.progress = ResearchProgress(run_id=ledger.run_id, iterations=ledger.iterations_started,
                                                    stop_reason=package.progress.stop_reason)
                self.emit(f"Research iteration {ledger.iterations_started}")
                passages: dict[str, str] = {}
                for turn in range(self.settings.max_turns_per_iteration):
                    soft = ledger.committed_budget_usd >= self.settings.soft_budget_usd
                    context = build_context(project, package, self.settings, soft, {
                        "iterations": self.settings.max_iterations - ledger.iterations_started,
                        "searches": self.settings.max_searches - ledger.search_calls,
                        "source_reads": self.settings.max_source_reads - ledger.source_reads,
                        "turns_in_iteration": self.settings.max_turns_per_iteration - turn,
                        "reserved_budget_remaining_usd": max(0, hard_budget - ledger.committed_budget_usd),
                        "completion_min_facts": self.settings.min_facts,
                        "completion_min_sources": self.settings.min_sources,
                    })
                    if soft:
                        self.emit("Soft budget reached; model asked to consolidate")
                    if observation:
                        size = len(json.dumps(observation[0].model_dump(), ensure_ascii=False)) + len(observation[1])
                        if size > self.settings.max_observation_chars:
                            raise LimitReached("observation_context_limit")
                    quote = self.provider.reserve_cost(context, observation, self.settings.max_output_tokens)
                    ledger.reserve(quote, hard_budget, "model", usage_path)
                    operation = "model_request"
                    reply = self.provider.decide(context, observation, self.settings.max_output_tokens)
                    ledger.record(reply.usage, usage_path)
                    call = reply.call
                    if call.name not in action_contracts():
                        raise ValueError("Unapproved research tool")
                    ledger.tool_calls += 1
                    ledger.persist(usage_path)
                    if call.name == "checkpoint_research":
                        operation = "artifact_validation"
                        update = ResearchUpdate.model_validate(call.arguments)
                        candidate = self._apply_update(package, update, passages)
                        candidate.progress.stop_reason = None
                        if update.recommendation == Recommendation.COMPLETE:
                            try:
                                self._check_completion(candidate)
                            except ValueError:
                                candidate.progress.stop_reason = "completion_requirements_not_met"
                            else:
                                candidate.progress.status = ResearchRunStatus.COMPLETE
                        package = candidate
                        self._checkpoint(package, store)
                        observation = None
                        if package.progress.status == ResearchRunStatus.COMPLETE:
                            self._finish_workflow(machine, state_path)
                            self._summary(package, ledger)
                            return package
                        break
                    if call.name == "search_web":
                        request = SearchRequest.model_validate(call.arguments)
                        if ledger.search_calls >= self.settings.max_searches:
                            raise LimitReached("search_limit")
                        ledger.reserve(self.tools.search_reserve_cost(request.query), hard_budget, "search", usage_path)
                        self.emit(f"Tool: search_web query={request.query}")
                        operation = "web_search"
                        result = self.tools.search_web(request.query)
                    else:
                        request = ReadRequest.model_validate(call.arguments)
                        source = next((s for s in package.sources if s.source_id == request.source_id), None)
                        if source is None:
                            raise ValueError("Only discovered sources may be read")
                        if ledger.source_reads >= self.settings.max_source_reads:
                            raise LimitReached("source_read_limit")
                        ledger.reserve(0, hard_budget, "read", usage_path)
                        self.emit(f"Tool: read_source {source.source_id}")
                        operation = "source_read"
                        result = self.tools.read_source(source, self.settings.max_page_chars)
                    ledger.record(result.usage, usage_path)
                    if call.name == "search_web":
                        if result.kind != "search":
                            raise ValueError("Search observations cannot supply fetched evidence")
                        result.text = ""
                    elif (result.kind != "source" or result.source_id != source.source_id
                          or len(result.sources) != 1
                          or canonical_url(str(result.sources[0].url)) != canonical_url(str(source.url))):
                        raise ValueError("Read observation must match the requested source")
                    result = self._merge_sources(package, result)
                    if result.kind == "source" and result.source_id:
                        passages[result.source_id] = normalize_text(result.text)
                    output = result.model_dump_json(exclude={"usage"})
                    observation = (call, output)
                else:
                    raise LimitReached("turn_limit")
            except (LimitReached, ContextLimitError) as exc:
                package.progress = ResearchProgress(run_id=ledger.run_id, iterations=ledger.iterations_started,
                    status=ResearchRunStatus.LIMIT_REACHED, stop_reason=str(exc))
                self._checkpoint(package, store)
                # Research remains resumable, but this is not successful completion.
                write_json(state_path, machine.state, replace=True)
                self._summary(package, ledger)
                return package
            except Exception:
                # Third-party exception text can contain credentials, request bodies or pages.
                # Persist only a safe operational code, never raw exception messages.
                if ledger.pending_request:
                    ledger.unknown_usage = True
                ledger.persist(usage_path)
                package.progress = ResearchProgress(run_id=ledger.run_id, iterations=ledger.iterations_started,
                    status=ResearchRunStatus.FAILED, stop_reason=f"research_{operation}_failed")
                try:
                    self._checkpoint(package, store)
                finally:
                    if machine.state.current_state != ProjectState.FAILED:
                        machine.fail(f"research_{operation}_failed; inspect configuration/connectivity and retry research")
                    write_json(state_path, machine.state, replace=True)
                self._summary(package, ledger)
                return package

    def _merge_sources(self, package: ResearchPackage, result: ToolObservation) -> ToolObservation:
        known = {canonical_url(str(source.url)): source for source in package.sources}
        result = result.model_copy(deep=True)
        remapped = []
        for source in result.sources:
            url = canonical_url(str(source.url))
            normalized = source_reference(url, source.title)
            source = source.model_copy(update={"source_id": normalized.source_id, "url": normalized.url})
            if url in known and result.kind != "source":
                source = known[url]
            known[url] = source
            remapped.append(source)
        if result.source_id and len(remapped) == 1:
            result.source_id = remapped[0].source_id
        result.sources = remapped
        result.text = result.text[:self.settings.max_page_chars]
        package.sources = list(known.values())
        return result

    def _apply_update(self, package: ResearchPackage, update: ResearchUpdate,
                      passages: dict[str, str]) -> ResearchPackage:
        existing_gaps = {gap.gap_id: gap for gap in package.plan.gaps}
        new_gaps = {gap.gap_id: gap for gap in update.plan.gaps}
        for gap_id, old in existing_gaps.items():
            if gap_id not in new_gaps or (new_gaps[gap_id].question, new_gaps[gap_id].critical) != (old.question, old.critical):
                raise ValueError("Existing research gaps cannot be silently dropped or redefined")
        facts = {fact.fact_id: fact for fact in package.facts}
        prior_evidence = {(e.source_id, e.excerpt) for f in package.facts for e in f.evidence}
        for fact in update.facts:
            if fact.fact_id in facts and facts[fact.fact_id].claim != fact.claim:
                raise ValueError("A stable fact ID cannot be reassigned to a different claim")
            for evidence in fact.evidence:
                quote = normalize_text(evidence.excerpt)
                if (evidence.source_id, evidence.excerpt) not in prior_evidence:
                    if not quote or quote not in passages.get(evidence.source_id, ""):
                        raise ValueError("Evidence must be an exact excerpt of a read source")
            facts[fact.fact_id] = fact
        data = package.model_dump()
        data.update(plan=update.plan, facts=list(facts.values()))
        return ResearchPackage.model_validate(data)

    def _check_completion(self, package: ResearchPackage) -> None:
        cited = {e.source_id for fact in package.facts for e in fact.evidence}
        if (len(package.facts) < self.settings.min_facts or len(cited) < self.settings.min_sources
                or not package.plan.gaps or not package.plan.coverage_summary.strip()
                or any(g.critical and g.status != GapStatus.COVERED for g in package.plan.gaps)):
            raise ValueError("Completion requires coverage, enough facts and enough cited sources")

    def _checkpoint(self, package: ResearchPackage, store: ArtifactStore) -> None:
        # Revalidate after mutations before making the entire package durable.
        package = ResearchPackage.model_validate(package.model_dump())
        version = store.save("research", package)
        self.emit(f"Checkpoint research_v{version}: {len(package.facts)} facts, {len(package.sources)} sources")

    def _finish_workflow(self, machine: ProjectStateMachine, path: Path) -> None:
        if machine.state.current_state == ProjectState.FAILED:
            machine.recover()
        if machine.state.current_state == ProjectState.CREATED:
            machine.transition(ProjectState.RESEARCHING)
        if machine.state.current_state == ProjectState.RESEARCHING:
            machine.transition(ProjectState.RESEARCH_COMPLETE)
        write_json(path, machine.state, replace=True)

    def _summary(self, package: ResearchPackage, ledger: UsageLedger) -> None:
        self.emit(f"Research {package.progress.status}: {package.progress.stop_reason or 'coverage accepted'}; "
                  f"{ledger.model_calls} model calls, {ledger.search_calls} searches, {ledger.source_reads} reads; "
                  f"estimated USD {ledger.estimated_total_cost_usd:.4f}, "
                  f"reserved USD {ledger.committed_budget_usd:.4f}, unknown usage={ledger.unknown_usage}")
