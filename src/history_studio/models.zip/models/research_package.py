from enum import StrEnum
from typing import Literal, Self

from pydantic import Field, model_validator

from .base import Contract, Identifier, Text, require_unique
from .research import ResearchFact
from .sources import SourceReference


class GapStatus(StrEnum):
    OPEN = "OPEN"
    INVESTIGATING = "INVESTIGATING"
    COVERED = "COVERED"


class ResearchGap(Contract):
    gap_id: Identifier
    question: Text = Field(max_length=600)
    critical: bool = True
    status: GapStatus = GapStatus.OPEN
    fact_ids: list[Identifier] = Field(default_factory=list)


class ResearchPlan(Contract):
    gaps: list[ResearchGap] = Field(default_factory=list, max_length=30)
    coverage_summary: str = Field(default="", max_length=1500)

    @model_validator(mode="after")
    def unique_gaps(self) -> Self:
        require_unique([gap.gap_id for gap in self.gaps], "Gap IDs")
        return self


class ResearchRunStatus(StrEnum):
    RUNNING = "RUNNING"
    COMPLETE = "COMPLETE"
    LIMIT_REACHED = "LIMIT_REACHED"
    FAILED = "FAILED"


class ResearchProgress(Contract):
    run_id: Identifier
    iterations: int = Field(default=0, ge=0)
    status: ResearchRunStatus = ResearchRunStatus.RUNNING
    stop_reason: str | None = None


class ResearchPackage(Contract):
    schema_version: Literal[2] = 2
    project_id: Identifier
    topic: Text
    research_scope: Text | None = None
    plan: ResearchPlan = Field(default_factory=ResearchPlan)
    facts: list[ResearchFact] = Field(default_factory=list)
    sources: list[SourceReference] = Field(default_factory=list)
    progress: ResearchProgress

    @model_validator(mode="after")
    def linked_provenance(self) -> Self:
        require_unique([fact.fact_id for fact in self.facts], "Fact IDs")
        require_unique([" ".join(fact.claim.split()).casefold() for fact in self.facts], "Atomic claims")
        require_unique([source.source_id for source in self.sources], "Source IDs")
        require_unique([str(source.url) for source in self.sources], "Source URLs")
        source_ids = {source.source_id for source in self.sources}
        fact_ids = {fact.fact_id for fact in self.facts}
        for fact in self.facts:
            if fact.sources or not fact.evidence or fact.historical_time is None:
                raise ValueError("Package facts require structured time and evidence-only provenance")
            if any(e.source_id not in source_ids for e in fact.evidence):
                raise ValueError("Evidence references an unknown source")
        for gap in self.plan.gaps:
            if not set(gap.fact_ids) <= fact_ids:
                raise ValueError("Gap references an unknown fact")
            if gap.status == GapStatus.COVERED and not gap.fact_ids:
                raise ValueError("Covered gaps require collected facts")
        if self.progress.status == ResearchRunStatus.COMPLETE:
            if not self.facts or not self.sources or not self.plan.gaps:
                raise ValueError("Complete research requires facts, sources and a plan")
            if any(g.critical and g.status != GapStatus.COVERED for g in self.plan.gaps):
                raise ValueError("Complete research cannot have unresolved critical gaps")
        return self

    def facts_without_research_notes(self) -> list[dict[str, object]]:
        """Explicit projection for future consumers; no story behavior is implemented."""
        return [fact.model_dump(mode="json", exclude={"research_notes", "sources"}) for fact in self.facts]
