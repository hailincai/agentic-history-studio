from enum import StrEnum
from typing import Self

from pydantic import Field, model_validator

from .base import Contract, Text


class TimePrecision(StrEnum):
    YEAR = "YEAR"
    APPROXIMATE = "APPROXIMATE"
    RANGE = "RANGE"
    CENTURY = "CENTURY"
    UNKNOWN = "UNKNOWN"


class HistoricalTime(Contract):
    """Signed astronomical years (0 = 1 BCE); original expressions remain intact."""

    display: Text
    start_year: int | None = Field(default=None, strict=True)
    end_year: int | None = Field(default=None, strict=True)
    precision: TimePrecision = TimePrecision.UNKNOWN

    @model_validator(mode="after")
    def ordered_years(self) -> Self:
        if self.end_year is not None and self.start_year is None:
            raise ValueError("End year requires a start year")
        if self.start_year is not None and self.end_year is not None and self.end_year < self.start_year:
            raise ValueError("Historical range must be chronological")
        if self.precision == TimePrecision.YEAR:
            if self.start_year is None or self.end_year not in (None, self.start_year):
                raise ValueError("YEAR requires a single year")
        if self.precision in (TimePrecision.RANGE, TimePrecision.CENTURY):
            if self.start_year is None or self.end_year is None:
                raise ValueError("Range/century precision requires both bounds")
        return self
